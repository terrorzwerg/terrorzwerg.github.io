//var lang = "de"; //en, nl, ru, cz, it, sp, de, fr, zh, he
//var twentyfour = true;
var clockrefresh = 2000; //milliseconds
var weatherrefresh = 10; //minutes
var batteryrefresh = 1; //minutes (requires infoStats)