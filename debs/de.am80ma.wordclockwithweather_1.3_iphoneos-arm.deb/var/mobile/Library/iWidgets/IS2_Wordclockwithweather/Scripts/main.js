/*credits to Austin ,Mat and June */
/*  moding translating by Am80mA  */
/*  brought to you by TeamIOS     */




var forecastdisplay = false;
if (forecastdisplay == false) { var touchmode = "touchend"; } else { var touchmode = "click"; }

function init(){
updateClock();
setInterval(updateClock, 1000);
updateHours();
setInterval(updateHours, 1000);
updateMinutes();
setInterval(updateMinutes, 1000);
document.getElementById("touchForecast").addEventListener(touchmode, touch, false);
}

function touch(event) {
	event.preventDefault();
	if (forecastdisplay == false) {
		document.getElementById("forecast").className = "fade-in";
		forecastdisplay = true;
	} else {
		document.getElementById("forecast").className = "fade-out";
		forecastdisplay = false;
	}
}

function updateClock() {
    var date = new Date;
    var year = date.getFullYear();
    var month = date.getMonth();
    var months = new Array('Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember');
    var d = date.getDate();
    var day = date.getDay();
    var days = new Array('Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag');
    var h = date.getHours();	
    if( h > 12 )  {
	h = ( h > 12 ) ? h - 12 : h;
//	h = ( h < 10 ? "0" : "" ) + h;
	h = ( h == 0 ) ? 12 : h;}	
    var m = date.getMinutes();
    if(m<10)  {m = "0"+m;}
    var s = date.getSeconds();
    if(s<10)  {s = "0"+s}
		
    var timeOfDay = date.getHours();	    
    if( timeOfDay < 12 ){
		document.getElementById("timeOfDay").innerHTML = "Morgens";
		
	}else if( timeOfDay >= 12 && timeOfDay <= 17 ){
		document.getElementById("timeOfDay").innerHTML = "Nachmittags";
		
	}else if ( timeOfDay > 17 && timeOfDay <= 24 ){
		document.getElementById("timeOfDay").innerHTML = "Abends";}
		
	document.getElementById("weekday").innerHTML = days[day];
	document.getElementById("date").innerHTML = d+'.'+months[month];  /* +' '+year;*/		
    document.getElementById("time").innerHTML = h+':'+m;
}

function updateHours ( ){
	var currentHours_name_array = new Array ("Null", "Ein", "Zwei", "Drei", "Vier", "Fünf", "Sechs", "Sieben", "Acht", "Neun", "Zehn", "Elf", "Zwölf", "Dreizehn", "Vierzehn", "Fünfzehn", "Sechzehn", "Siebzehn", "Achtzehn", "Neunzehn", "Zwanzig", "Einundzwanzig", "Zweiundzwanzig", "Dreiundzwanzig", "Null")
	var currentTime = new Date ( );
	var currentHours = currentTime.getHours ( );
<!-- Defines either "AM" or "PM" as appropriate -->
	var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
<!-- Convert hours component of "12" to "24" -->
	//currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
<!-- Convert hours component from "0" to "12 at Midnight-->
	//currentHours = ( currentHours == 0 ) ? 12 : currentHours;
<!-- Compose the string for display-->
	var currentTimeString = currentHours_name_array[currentHours];
<!-- Update the time display-->
      document.getElementById("hours").firstChild.nodeValue = currentTimeString;
}

function updateMinutes ( ){
	var currentMinutes_name_array = new Array ("Null", "Eins", "Zwei", "Drei", "Vier", "Fünf", "Sechs", "Sieben", "Acht", "Neun", "Zehn", "Elf", "Zwölf", "Dreizehn", "Vierzehn", "Fünfzehn", "Sechzehn", "Siebzehn", "Achtzehn", "Neunzehn", "Zwanzig", "Einundzwanzig", "Zweiundzwanzig", "Dreiundzwanzig", "Vierundzwanzig", "Fünfundzwanzig", "Sechsundzwanzig", "Siebenundzwanzig", "Achtundzwanzig", "Neunundzwanzig", "Dreißig", "Einunddreißig", "Zweiunddreißig", "Dreiunddreißig", "Vierunddreißig", "Fünfunddreißig", "Sechsunddreißig", "Siebenunddreißig", "Achtunddreißig", "Neununddreißig", "Vierzig", "Einundvierzig", "Zweiundvierzig", "Dreiundvierzig", "Vierundvierzig", "Fünfundvierzig", "Sechsundvierzig", "Siebenundvierzig", "Achtundvierzig", "Neunundvierzig", "Fünfzig", "Einundfünfzig", "Zweiundfünfzig", "Dreiundfünfzig", "Vierundfünfzig", "Fünfundfünfzig", "Sechsundfünfzig", "Siebenundfünfzig", "Achtundfünfzig", "Neunundfünfzig")
	var currentTime = new Date ( );
	var currentHours = currentTime.getHours ( );
	var currentMinutes = currentTime.getMinutes ( );
<!-- Compose the string for display-->
	var currentTimeString = currentMinutes_name_array[currentMinutes]
<!-- Update the time display-->
document.getElementById("minutes").firstChild.nodeValue = currentTimeString;
}