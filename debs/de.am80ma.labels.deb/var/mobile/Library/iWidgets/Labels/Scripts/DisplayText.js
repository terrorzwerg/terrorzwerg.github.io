function init () 
{
	document.getElementById("divTextToDisplay").style.fontSize = fontSize + "px";
	var tst = (72 - parseInt(fontSize)) + 10;
	document.getElementById("divTextToDisplay").style.top = tst + "px";
	
	// set font family
	document.getElementById("divTextToDisplay").style.fontFamily = fontName;
	
	// set font color
	document.getElementById("divTextToDisplay").style.color = fontColor;
	
	// set text
	document.getElementById("divTextToDisplay").innerHTML = textToDisplay;
	
}